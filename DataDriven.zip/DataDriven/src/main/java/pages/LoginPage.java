package pages;

import org.json.JSONObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import base.Base;

/**
 * 
 * @author S Babu
 *
 */

public class LoginPage extends Base {

   @FindBy(id = "username")
    WebElement txtUsername;

   @FindBy(id = "password")
   WebElement txtPassword;


//   @FindBy(id="form-login")
   @FindBy(xpath ="//*[@id=\"t3-content\"]/div[2]/div[1]/form/fieldset/div[4]/div/button")
   WebElement btnLogin;


   @FindBy(xpath = "//*[@id=\"system-message\"]/div/div/p")
   WebElement spnMessage;


    public void userLogin(JSONObject data) throws Exception {

        txtUsername.clear();
        txtUsername.sendKeys(data.getString("USERNAME"));
        txtPassword.clear();
        txtPassword.sendKeys(data.getString("PASSWORD"));
        btnLogin.click();

        System.out.println("Username " + data.getString("USERNAME") + " Password " + data.getString("PASSWORD"));
    }



    public String getMessage(){
        return spnMessage.getText();
    }
}

